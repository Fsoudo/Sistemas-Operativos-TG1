#!/bin/bash

# Caminho base fixo onde estão os scripts
Base="/home/$USER/Sistemas-Operativos-TG1/tg1"
ScriptsDir="$Base/scripts"

opcao=""

while [ "$opcao" != "0" ]
do
    clear

    echo "==========================================="
    echo "        MASTER SCRIPT - TG1 (MENU)"
    echo "==========================================="
    echo ""
    echo "Escolhe o que queres executar:"
    echo ""
    echo " 1 - Req2  - Criar sub-corpus (200000 linhas)"
    echo " 2 - Req3  - Gerar informações do corpus"
    echo " 3 - Req4  - Criar ficheiro de palavras (words.txt)"
    echo " 4 - Req5  - Criar ficheiro de pares de palavras (words_pairs.txt)"
    echo " 5 - Req6  - Verificar pares de palavras vs words.txt"
    echo " 6 - Req7  - Criar ficheiro de frases (sentences.txt)"
    echo " 7 - Req8  - Criar ficheiro de pares de frases (sentences_pairs.txt)"
    echo " 8 - Req9  - Verificar pares de frases vs sentences.txt"
    echo " 9 - Req10 - Limitar sentences.txt a 250000 frases"
    echo "10 - Correr TODOS pela ordem correta"
    echo ""
    echo " 0 - Sair"
    echo ""
    echo -n "Opção: "
    read opcao

    if [ "$opcao" = "1" ]; then
        echo ""
        echo ">> [Req2] Criar sub-corpus"
        bash "$ScriptsDir/corpustxt_req2.sh"

    elif [ "$opcao" = "2" ]; then
        echo ""
        echo ">> [Req3] Informações do corpus"
        bash "$ScriptsDir/corpusInfo_req3.sh"

    elif [ "$opcao" = "3" ]; then
        echo ""
        echo ">> [Req4] Criar ficheiro de palavras"
        bash "$ScriptsDir/words_txt_req4.sh"

    elif [ "$opcao" = "4" ]; then
        echo ""
        echo ">> [Req5] Criar ficheiro de pares de palavras"
        bash "$ScriptsDir/create_word_pairs_req5.sh"

    elif [ "$opcao" = "5" ]; then
        echo ""
        echo ">> [Req6] Verificar pares de palavras"
        bash "$ScriptsDir/verifica_palavras_pares_req6.sh"

    elif [ "$opcao" = "6" ]; then
        echo ""
        echo ">> [Req7] Criar ficheiro de frases"
        bash "$ScriptsDir/corpus_sentences_req7.sh"

    elif [ "$opcao" = "7" ]; then
        echo ""
        echo ">> [Req8] Criar ficheiro de pares de frases"
        bash "$ScriptsDir/sentences_pairs_req8.sh"

    elif [ "$opcao" = "8" ]; then
        echo ""
        echo ">> [Req9] Verificar pares de frases"
        bash "$ScriptsDir/check_sentences_pairs_req9.sh"

    elif [ "$opcao" = "9" ]; then
        echo ""
        echo ">> [Req10] Limitar sentences.txt"
        bash "$ScriptsDir/limit_sentences_req10.sh"

    elif [ "$opcao" = "10" ]; then
        echo ""
        echo ">> A correr todos os requisitos..."
        bash "$ScriptsDir/corpustxt_req2.sh"
        bash "$ScriptsDir/corpusInfo_req3.sh"
        bash "$ScriptsDir/words_txt_req4.sh"
        bash "$ScriptsDir/create_word_pairs_req5.sh"
        bash "$ScriptsDir/verifica_palavras_pares_req6.sh"
        bash "$ScriptsDir/corpus_sentences_req7.sh"
        bash "$ScriptsDir/sentences_pairs_req8.sh"
        bash "$ScriptsDir/check_sentences_pairs_req9.sh"
        bash "$ScriptsDir/limit_sentences_req10.sh"
        echo "Execução concluída."

    elif [ "$opcao" = "0" ]; then
        echo ""
        echo "A sair..."

    else
        echo ""
        echo "Opção inválida."
    fi

    if [ "$opcao" != "0" ]; then
        echo ""
        echo "Pressiona ENTER para voltar ao menu..."
        read pausa
    fi
done