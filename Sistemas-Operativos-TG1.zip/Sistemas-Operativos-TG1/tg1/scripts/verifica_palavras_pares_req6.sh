#!/bin/bash

FICHEIRO_PALAVRAS="/home/$USER/Sistemas-Operativos-TG1/tg1/words_dict/words.txt"
FICHEIRO_PARES="/home/$USER/Sistemas-Operativos-TG1/tg1/words_dict/words_pairs.txt"
LISTA_TEMP="/tmp/lista_palavras_tg1.txt"

if [ ! -f "$FICHEIRO_PALAVRAS" ]; then
    echo "Erro: ficheiro de palavras nao encontrado em $FICHEIRO_PALAVRAS"
    exit 1
fi

if [ ! -f "$FICHEIRO_PARES" ]; then
    echo "Erro: ficheiro de pares de palavras nao encontrado em $FICHEIRO_PARES"
    exit 1
fi

awk '{print $1}' "$FICHEIRO_PALAVRAS" | sort -u > "$LISTA_TEMP"

ERROS=0

while read -r W1 W2 OCOR; do
    if ! grep -qx "$W1" "$LISTA_TEMP"; then
        echo "Palavra em falta no dicionario: $W1 (no par: $W1 $W2)"
        ERROS=1
    fi
    if ! grep -qx "$W2" "$LISTA_TEMP"; then
        echo "Palavra em falta no dicionario: $W2 (no par: $W1 $W2)"
        ERROS=1
    fi
done < "$FICHEIRO_PARES"

if [ "$ERROS" -eq 0 ]; then
    echo "Todos os pares de palavras utilizam palavras existentes em words.txt."
fi

rm -f "$LISTA_TEMP"