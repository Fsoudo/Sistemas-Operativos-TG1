#!/bin/bash

# Ficheiro original descarregado
FICHEIRO_ORIGINAL="/home/$USER/Downloads/paisa.raw.utf8"

# Ficheiro de trabalho no projeto
FICHEIRO_TRABALHO="/home/$USER/Sistemas-Operativos-TG1/tg1/corpus/corpus_txt/paisa.raw.utf8"


if [ -f "$FICHEIRO_ORIGINAL" ]; then
    echo "Ficheiro original encontrado em: $FICHEIRO_ORIGINAL"
    echo "A extrair as primeiras 200000 linhas..."

    head -200000 "$FICHEIRO_ORIGINAL" > "$FICHEIRO_TRABALHO"

    CONTAR_LINHAS=$(wc -l < "$FICHEIRO_TRABALHO")

    if [ "$CONTAR_LINHAS" -eq 200000 ]; then
        echo "Linhas extraídas com sucesso para: $FICHEIRO_TRABALHO"
    else
        echo "Aviso: o ficheiro criado tem $CONTAR_LINHAS linhas (esperado: 200000)."
    fi
else
    echo "Erro: o ficheiro $FICHEIRO_ORIGINAL não foi encontrado."
    exit 1
fi
