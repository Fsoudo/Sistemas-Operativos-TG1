#!/bin/bash

FICHEIRO_CORPUS="/home/$USER/Sistemas-Operativos-TG1/tg1/corpus/corpus_txt/paisa.raw.utf8"
FICHEIRO_SAIDA="/home/$USER/Sistemas-Operativos-TG1/tg1/words_dict/words_pairs.txt"

mkdir -p "/home/francisco/Sistemas-Operativos-TG1/tg1/words_dict"

if [ ! -f "$FICHEIRO_CORPUS" ]; then
    echo "Erro: ficheiro de corpus não encontrado em $FICHEIRO_CORPUS"
    exit 1
fi

awk '
{
    for (i = 1; i < NF; i++) {
        pair = $i" "$(i+1)
        count[pair]++
    }
}
END {
    for (p in count) {
        print p" "count[p]
    }
}
' "$FICHEIRO_CORPUS" | sort > "$FICHEIRO_SAIDA"

echo "Ficheiro de pares de palavras criado em: $FICHEIRO_SAIDA"

