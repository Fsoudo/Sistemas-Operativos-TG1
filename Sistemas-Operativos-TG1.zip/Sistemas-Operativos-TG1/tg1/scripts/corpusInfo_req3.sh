#!/bin/bash

FICHEIRO_CORPUS="/home/$USER/Sistemas-Operativos-TG1/tg1/corpus/corpus_txt/paisa.raw.utf8"
RESULTADO="/home/$USER/Sistemas-Operativos-TG1/tg1/corpus/corpus_info/corpus_info.txt"


if [ ! -f "$FICHEIRO_CORPUS" ]; then
    echo "Erro: ficheiro de corpus não encontrado em $FICHEIRO_CORPUS"
    exit 1
fi

# Número total de caracteres
NUM_CARACTERES=$(wc -c < "$FICHEIRO_CORPUS")

# Linhas não vazias
LINHAS_NAO_VAZIAS=$(grep -cve '^[[:space:]]*$' "$FICHEIRO_CORPUS")

# Número total de palavras
TOTAL_PALAVRAS=$(wc -w < "$FICHEIRO_CORPUS")

# Número total de palavras diferentes
TOTAL_PALAVRAS_DIFERENTES=$(tr '[:space:]' '\n' < "$FICHEIRO_CORPUS" | grep -v '^$' | sort | uniq | wc -l)

# Quociente palavras diferentes / total de palavras
if [ "$TOTAL_PALAVRAS" -gt 0 ]; then
    QUOCIENTE_PALAVRAS=$(awk -v a="$TOTAL_PALAVRAS_DIFERENTES" -v b="$TOTAL_PALAVRAS" 'BEGIN{printf "%.6f", a/b}')
else
    QUOCIENTE_PALAVRAS="0"
fi

# Número total de frases (considera cada linha não vazia como frase)
TOTAL_FRASES="$LINHAS_NAO_VAZIAS"

# Número total de frases diferentes
TOTAL_FRASES_DIFERENTES=$(grep -ve '^[[:space:]]*$' "$FICHEIRO_CORPUS" | sort | uniq | wc -l)

# Quociente frases diferentes / total de frases
if [ "$TOTAL_FRASES" -gt 0 ]; then
    QUOCIENTE_FRASES=$(awk -v a="$TOTAL_FRASES_DIFERENTES" -v b="$TOTAL_FRASES" 'BEGIN{printf "%.6f", a/b}')
else
    QUOCIENTE_FRASES="0"
fi

# Escreve resultados
{
    echo "Numero de caracteres: $NUM_CARACTERES"
    echo "Quantidade de linhas nao vazias: $LINHAS_NAO_VAZIAS"
    echo "Numero total de palavras: $TOTAL_PALAVRAS"
    echo "Numero total de palavras diferentes: $TOTAL_PALAVRAS_DIFERENTES"
    echo "Quociente (palavras diferentes / total de palavras): $QUOCIENTE_PALAVRAS"
    echo "Numero total de frases: $TOTAL_FRASES"
    echo "Numero total de frases diferentes: $TOTAL_FRASES_DIFERENTES"
    echo "Quociente (frases diferentes / total de frases): $QUOCIENTE_FRASES"
} > "$RESULTADO"

echo "Informacao do corpus escrita em: $RESULTADO"


