#!/bin/bash

# Caminhos fixos
Ficheiro_Trabalho="/home/$USER/Sistemas-Operativos-TG1/tg1/corpus_txt/paisa.raw.utf8"
Resultado="/home/$USER/Sistemas-Operativos-TG1/tg1/sentences_dict/sentences_pairs.txt"

# Verificação do corpus
if [ ! -f "$Ficheiro_Trabalho" ]; then
    echo "Erro: Ficheiro $Ficheiro_Trabalho não encontrado!"
    echo "Por favor, executa primeiro o script do requisito 2 para criar o sub-corpus (200.000 linhas)."
    exit 1
fi

# Diretoria de saída
mkdir -p "/home/$USER/Sistemas-Operativos-TG1/tg1/sentences_dict"

# Geração de sentences_pairs.txt
# 1) remove linhas vazias
# 2) normaliza espaços e remove espaços das pontas
# 3) troca espaços por '|'
# 4) cria pares de frases consecutivas e conta ocorrências
# 5) filtra pares em que cada frase tem comprimento <= 150 caracteres
# 6) imprime "frase1_com_pipes frase2_com_pipes contagem"
# 7) ordena alfabeticamente
grep -v '^[[:space:]]*$' "$Ficheiro_Trabalho" \
| sed -E 's/[[:space:]]+/ /g; s/^ //; s/ $//' \
| sed 's/ /|/g' \
| awk '
    NR==1 { prev=$0; next }
    {
        pair = prev " " $0
        count[pair]++
        prev = $0
    }
    END {
        for (p in count) print p, count[p]
    }
' \
| awk '
    {
        frase1 = $1
        frase2 = $2
        freq   = $3
        if (length(frase1) <= 150 && length(frase2) <= 150)
            print frase1, frase2, freq
    }
' \
| sort > "$Resultado"

echo "Ficheiro de pares de frases criado (com filtro de comprimento): $Resultado"
echo "Total de pares únicos: $(wc -l < "$Resultado")"
