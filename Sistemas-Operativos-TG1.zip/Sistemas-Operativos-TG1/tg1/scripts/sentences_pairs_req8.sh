#!/bin/bash

FICHEIRO_CORPUS="/home/$USER/Sistemas-Operativos-TG1/tg1/corpus/corpus_txt/paisa.raw.utf8"
FICHEIRO_SAIDA="/home/$USER/Sistemas-Operativos-TG1/tg1/sentences_dict/sentences_pairs.txt"

if [ ! -f "$FICHEIRO_CORPUS" ]; then
    echo "Erro: ficheiro de corpus nao encontrado em $FICHEIRO_CORPUS"
    exit 1
fi

awk '
NF > 0 {
    frase = $0
    gsub(" ", "|", frase)
    if (prev != "") {
        par = prev" "frase
        count[par]++
    }
    prev = frase
}
END {
    for (p in count) {
        print p" "count[p]
    }
}
' "$FICHEIRO_CORPUS" | sort > "$FICHEIRO_SAIDA"

echo "Ficheiro de pares de frases criado em: $FICHEIRO_SAIDA"
