#!/bin/bash

FICHEIRO_CORPUS="/home/$USER/Sistemas-Operativos-TG1/tg1/corpus/corpus_txt/paisa.raw.utf8"
FICHEIRO_SAIDA="/home/$USER/Sistemas-Operativos-TG1/tg1/words_dict/words.txt"


if [ ! -f "$FICHEIRO_CORPUS" ]; then
    echo "Erro: ficheiro de corpus não encontrado em $FICHEIRO_CORPUS"
    exit 1
fi

tr '[:space:]' '\n' < "$FICHEIRO_CORPUS" \
    | grep -v '^$' \
    | sort \
    | uniq -c \
    | awk '{print $2" "$1}' \
    | sort > "$FICHEIRO_SAIDA"

echo "Ficheiro de palavras criado em: $FICHEIRO_SAIDA"

